#SXD20|20005|50541|50329|2015.07.08 17:14:22|hwcms5|0|12|3|
#TA admins`1`16384|languages`1`16384|nodes`0`16384|object2mod`0`16384|object_group`0`16384|object_interact`0`16384|object_multiple`0`16384|object_relation`0`16384|object_visual`0`16384|objects`0`16384|pages`1`16384|sessions`0`16384
#EOH

#	TC`admins`utf8_general_ci	;
CREATE TABLE `admins` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `uniq_id` varchar(32) DEFAULT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  `reg_date` timestamp NULL DEFAULT NULL,
  `upd_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `vis_date` timestamp NULL DEFAULT NULL,
  `nick` varchar(32) NOT NULL,
  `passw` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_set` (`passw`,`nick`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`admins`utf8_general_ci	;
INSERT INTO `admins` VALUES 
(1,\N,'1','2011-11-13 15:46:17','2014-12-16 22:56:20',\N,'admin','21232f297a57a5a743894a0e4a801fc3')	;
#	TC`languages`utf8_general_ci	;
CREATE TABLE `languages` (
  `strid` varchar(3) NOT NULL,
  `title` varchar(32) NOT NULL,
  `def` tinyint(1) NOT NULL,
  `def_tpl` varchar(128) NOT NULL,
  `encoding` varchar(16) NOT NULL DEFAULT 'utf-8',
  UNIQUE KEY `strid` (`strid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с языкавыми версиями сайта'	;
#	TD`languages`utf8_general_ci	;
INSERT INTO `languages` VALUES 
('ru','Русский',1,'','utf-8')	;
#	TC`nodes`utf8_general_ci	;
CREATE TABLE `nodes` (
  `node_id` int(13) NOT NULL AUTO_INCREMENT,
  `parent_id` int(13) NOT NULL DEFAULT '0',
  `nick` varchar(128) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `title` int(11) NOT NULL,
  `ord` int(7) NOT NULL,
  `act` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`node_id`),
  KEY `path` (`path`),
  KEY `nick` (`nick`),
  KEY `act` (`act`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Узловые древовидные структуры'	;
#	TC`object2mod`utf8_general_ci	;
CREATE TABLE `object2mod` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `obj_id` int(12) NOT NULL,
  `title` varchar(255) NOT NULL,
  `nick` varchar(128) NOT NULL,
  `module` varchar(64) DEFAULT NULL COMMENT 'Название модуля',
  `module_sect` varchar(64) DEFAULT NULL,
  `structure` blob NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq` (`obj_id`,`module`,`module_sect`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`object_group`utf8_general_ci	;
CREATE TABLE `object_group` (
  `obj_id` int(12) NOT NULL,
  `data` text NOT NULL,
  UNIQUE KEY `eid` (`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`object_interact`utf8_general_ci	;
CREATE TABLE `object_interact` (
  `obj_id` int(12) NOT NULL,
  `data` text NOT NULL,
  UNIQUE KEY `eid` (`obj_id`),
  CONSTRAINT `object_interact_ibfk_1` FOREIGN KEY (`obj_id`) REFERENCES `objects` (`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`object_multiple`utf8_general_ci	;
CREATE TABLE `object_multiple` (
  `obj_id` int(12) NOT NULL,
  `data` text NOT NULL,
  UNIQUE KEY `eid` (`obj_id`),
  CONSTRAINT `object_multiple_ibfk_1` FOREIGN KEY (`obj_id`) REFERENCES `objects` (`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`object_relation`utf8_general_ci	;
CREATE TABLE `object_relation` (
  `obj_id` int(12) NOT NULL,
  `data` text NOT NULL,
  UNIQUE KEY `eid` (`obj_id`),
  CONSTRAINT `object_relation_ibfk_1` FOREIGN KEY (`obj_id`) REFERENCES `objects` (`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`object_visual`utf8_general_ci	;
CREATE TABLE `object_visual` (
  `obj_id` int(12) NOT NULL,
  `data` longtext NOT NULL,
  UNIQUE KEY `eid` (`obj_id`),
  CONSTRAINT `object_visual_ibfk_1` FOREIGN KEY (`obj_id`) REFERENCES `objects` (`obj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`objects`utf8_general_ci	;
CREATE TABLE `objects` (
  `obj_id` int(12) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `nick` varchar(128) NOT NULL COMMENT 'Псевдоним объекта',
  `type` enum('visual','interact','group','multiple','relation') NOT NULL COMMENT 'Тип контента объекта',
  `ord` int(4) NOT NULL,
  `ogroup` int(10) NOT NULL COMMENT 'Группа объекта',
  PRIMARY KEY (`obj_id`),
  KEY `nick` (`nick`),
  KEY `type` (`type`),
  KEY `ord` (`ord`),
  KEY `egroup` (`ogroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`pages`utf8_general_ci	;
CREATE TABLE `pages` (
  `page_id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(13) unsigned NOT NULL DEFAULT '0' COMMENT 'id узла',
  `path` varchar(255) NOT NULL COMMENT 'Кэш пути до страницы',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`page_id`),
  KEY `parent` (`node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Страницы сайта. Узловые элементы структуры.'	;
#	TD`pages`utf8_general_ci	;
INSERT INTO `pages` VALUES 
(1,0,'','home')	;
#	TC`sessions`utf8_general_ci	;
CREATE TABLE `sessions` (
  `id` varchar(32) NOT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `type` enum('user','admin') NOT NULL DEFAULT 'user',
  `blocked` enum('1','0') NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `type` (`type`),
  KEY `blocked` (`blocked`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
