#SXD20|20005|50545|50444|2016.02.09 22:39:18|hwcms5|utf8|4|17|
#TA admins`1`16384|languages`2`16384|nodes`7`16384|pages`7`16384
#EOH

#	TC`admins`utf8_general_ci	;
CREATE TABLE `admins` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `uniq_id` varchar(32) DEFAULT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  `reg_date` timestamp NULL DEFAULT NULL,
  `upd_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `vis_date` timestamp NULL DEFAULT NULL,
  `nick` varchar(32) NOT NULL,
  `passw` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_set` (`passw`,`nick`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`admins`utf8_general_ci	;
INSERT INTO `admins` VALUES 
(1,\N,'1','2011-11-13 14:46:17','2014-12-16 21:56:20',\N,'admin','21232f297a57a5a743894a0e4a801fc3')	;
#	TC`languages`utf8_general_ci	;
CREATE TABLE `languages` (
  `strid` varchar(3) NOT NULL,
  `title` varchar(32) NOT NULL,
  `def` tinyint(1) NOT NULL,
  `def_tpl` varchar(128) NOT NULL,
  `encoding` varchar(16) NOT NULL DEFAULT 'utf-8',
  UNIQUE KEY `strid` (`strid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с языкавыми версиями сайта'	;
#	TD`languages`utf8_general_ci	;
INSERT INTO `languages` VALUES 
('de','Немецкий',0,'','utf-8'),
('ru','Русский',1,'','utf-8')	;
#	TC`nodes`utf8_general_ci	;
CREATE TABLE `nodes` (
  `node_id` int(13) NOT NULL AUTO_INCREMENT,
  `parent_id` int(13) NOT NULL DEFAULT '0',
  `context` varchar(64) NOT NULL COMMENT 'Контекст (название дерева), уникальный для дерева целиком. Например для страниц сайта это значение будет - pages',
  `node_path` text COMMENT 'Путь до узла от корня дерева',
  `node_ord` int(7) NOT NULL DEFAULT '0',
  PRIMARY KEY (`node_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='Узловые древовидные структуры'	;
#	TD`nodes`utf8_general_ci	;
INSERT INTO `nodes` VALUES 
(1,0,'0',\N,1),
(2,0,'0',\N,2),
(3,2,'0',\N,0),
(4,2,'0',\N,0),
(5,1,'0',\N,0),
(6,5,'',\N,0),
(7,1,'',\N,0)	;
#	TC`pages`utf8_general_ci	;
CREATE TABLE `pages` (
  `page_id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(13) unsigned NOT NULL DEFAULT '0' COMMENT 'id узла',
  `modules` text NOT NULL COMMENT 'Назначение и настройка модулей, используемых на странице',
  `act` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Активность страницы (вкл. для всех - 1; вкл. для зарег. польз. - 2; выкл. - 0)',
  `vis` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Видимость страницы (вкл. - 1; выкл. - 0)',
  `def` tinyint(1) NOT NULL DEFAULT '0',
  `nick` varchar(128) NOT NULL COMMENT 'Псевдоним страницы на латинице для использования в URL',
  `page_path` text NOT NULL COMMENT 'Кэш пути до страницы в иерархии (nick0/nick1/nick2/...)',
  `title` varchar(128) NOT NULL,
  `body` longtext NOT NULL,
  PRIMARY KEY (`page_id`),
  KEY `parent` (`node_id`),
  KEY `node_id` (`node_id`),
  KEY `act` (`act`,`vis`),
  KEY `nick` (`nick`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='Страницы сайта. Узловые элементы структуры.'	;
#	TD`pages`utf8_general_ci	;
INSERT INTO `pages` VALUES 
(2,1,'',2,1,1,'about_us','about_us','О нас','Проверка'),
(3,2,'',1,1,0,'contacts','','Контакты','Снова проверка...'),
(4,3,'',1,1,0,'moscow','','Москва',''),
(5,4,'',1,1,0,'piter','','Питер',''),
(6,5,'',1,1,0,'detaled','','Подробно','Подробная информация о нас'),
(7,6,'',1,0,0,'history','','История',''),
(8,7,'',1,1,0,'planes','','Планы на будущее','')	;
