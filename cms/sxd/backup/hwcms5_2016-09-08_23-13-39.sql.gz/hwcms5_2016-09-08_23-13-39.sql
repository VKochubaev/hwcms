#SXD20|20005|50548|50329|2016.09.08 23:13:39|hwcms5|utf8|5|18|
#TA admins`1`16384|languages`2`16384|nodes`7`16384|pages`7`16384|seo`1`16384
#EOH

#	TC`admins`utf8_general_ci	;
CREATE TABLE `admins` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `uniq_id` varchar(32) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `reg_date` timestamp NULL DEFAULT NULL,
  `upd_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `vis_date` timestamp NULL DEFAULT NULL,
  `nick` varchar(32) NOT NULL,
  `passw` varchar(32) NOT NULL,
  `session_data` mediumtext COMMENT 'Информация относящаяся к параметрам окружения пользователя. При стартк сессии данные извлекаются в сессию.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_set` (`passw`,`nick`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`admins`utf8_general_ci	;
INSERT INTO `admins` VALUES 
(1,\N,1,'2011-11-13 14:46:17','2014-12-16 21:56:20',\N,'admin','21232f297a57a5a743894a0e4a801fc3',\N)	;
#	TC`languages`utf8_general_ci	;
CREATE TABLE `languages` (
  `strid` varchar(3) NOT NULL,
  `title` varchar(32) NOT NULL,
  `def` tinyint(1) NOT NULL,
  `def_tpl` varchar(128) NOT NULL,
  `encoding` varchar(16) NOT NULL DEFAULT 'utf-8',
  UNIQUE KEY `strid` (`strid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Таблица с языкавыми версиями сайта'	;
#	TD`languages`utf8_general_ci	;
INSERT INTO `languages` VALUES 
('de','Немецкий',0,'','utf-8'),
('ru','Русский',1,'','utf-8')	;
#	TC`nodes`utf8_general_ci	;
CREATE TABLE `nodes` (
  `node_id` int(13) NOT NULL AUTO_INCREMENT,
  `parent_id` int(13) NOT NULL DEFAULT '0',
  `context` varchar(64) NOT NULL COMMENT 'Контекст (название дерева), уникальный для дерева целиком. Например для страниц сайта это значение будет - pages',
  `node_path` text COMMENT 'Путь до узла от корня дерева',
  `node_ord` int(7) NOT NULL DEFAULT '0',
  PRIMARY KEY (`node_id`),
  UNIQUE KEY `node_uniq` (`context`,`node_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='Узловые древовидные структуры'	;
#	TD`nodes`utf8_general_ci	;
INSERT INTO `nodes` VALUES 
(1,0,'pages',\N,1),
(2,0,'pages',\N,2),
(3,2,'pages',\N,0),
(4,2,'pages',\N,0),
(5,1,'pages',\N,0),
(6,5,'pages',\N,0),
(7,1,'pages',\N,0)	;
#	TC`pages`utf8_general_ci	;
CREATE TABLE `pages` (
  `page_id` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `node_id` int(13) unsigned NOT NULL DEFAULT '0' COMMENT 'id узла',
  `modules` text NOT NULL COMMENT 'Назначение и настройка модулей, используемых на странице',
  `act` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Активность страницы (вкл. для всех - 1; вкл. для зарег. польз. - 2; выкл. - 0)',
  `vis` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Видимость страницы (вкл. - 1; выкл. - 0)',
  `def` tinyint(1) NOT NULL DEFAULT '0',
  `nick` varchar(128) NOT NULL COMMENT 'Псевдоним страницы на латинице для использования в URL',
  `page_path` text NOT NULL COMMENT 'Кэш пути до страницы в иерархии (nick0/nick1/nick2/...)',
  `mdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Время изменения страницы',
  `title` varchar(128) NOT NULL,
  `body` longtext NOT NULL,
  PRIMARY KEY (`page_id`),
  KEY `parent` (`node_id`),
  KEY `node_id` (`node_id`),
  KEY `act` (`act`,`vis`),
  KEY `nick` (`nick`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='Страницы сайта. Узловые элементы структуры.'	;
#	TD`pages`utf8_general_ci	;
INSERT INTO `pages` VALUES 
(2,1,'',1,1,1,'about_us','','2016-09-08 22:34:59','О нас','Проверка {\'Привет\'|upper}'),
(3,2,'',1,1,0,'contacts','','0000-00-00 00:00:00','Контакты','Снова проверка...'),
(4,3,'',1,1,0,'moscow','','2016-09-04 17:52:38','Москва',''),
(5,4,'',1,1,0,'piter','','0000-00-00 00:00:00','Питер',''),
(6,5,'',1,1,0,'detaled','','2016-09-04 17:34:06','Подробно','Подробная информация о нас'),
(7,6,'',1,1,0,'history','','0000-00-00 00:00:00','История',''),
(8,7,'',1,1,0,'planes','','2016-09-04 17:36:57','Планы на будущее','')	;
#	TC`seo`utf8_general_ci	;
CREATE TABLE `seo` (
  `seo_context_id` int(16) DEFAULT NULL COMMENT 'Идентификатор  в контексте. Для страниц это будит значени еполя page_id',
  `seo_context` varchar(32) DEFAULT NULL COMMENT 'Контекст SEO. Т.е. на пример для страниц это будит - pages',
  `seo_title` varchar(128) DEFAULT NULL,
  `seo_atitle` varchar(128) DEFAULT NULL,
  `seo_keyw` text,
  `seo_descr` text,
  UNIQUE KEY `seo_uniq` (`seo_context`,`seo_context_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Данные SEO'	;
#	TD`seo`utf8_general_ci	;
INSERT INTO `seo` VALUES 
(2,'pages','','','','')	;
